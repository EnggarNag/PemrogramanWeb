# Contoh Aplikasi CRUD PHP MySQL dengan Framework CodeIgniter 4

## CRUD CodeIgniter 4

Contoh aplikasi CRUD pegawai yang dibuat dengan Framework CodeIgniter versi 4.0.3

Source code aplikasi ini berasal dari tutorial di blog [fahmialazhar.com](https://fahmialazhar.com).

## Cara Menjalankan Demo

Langkah menjalankan demo ini di localhost:

- Clone/download repository ini
- Jalankan composer update
- Import database
- Jalankan php spark serve
- Happy learning