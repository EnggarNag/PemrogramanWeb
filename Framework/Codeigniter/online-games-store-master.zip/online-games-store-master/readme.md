# Online Games Store

This project built with framework Codeigniter 3 and MySql

Login with admin role:


email: admin@gmail.com


pass : admin

![alt text](https://github.com/tegarpratama/online-games-store/blob/master/capture-1.png?raw=true) 

![alt text](https://github.com/tegarpratama/online-games-store/blob/master/capture-2.png?raw=true) 
